tam = int(input("Digite um número: "))

for i in range(tam, 0, -1) :
    print((tam - i) * " ", i * "*")
#include <stdio.h>
#include <stdlib.h>

void read_line(char* string);
void binary_on_screen(const char *file_name);
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char* string_t;

void lendoString(string_t string);
void corrigindoString(string_t frase, string_t erro, string_t correcao, string_t fraseCorrigida);
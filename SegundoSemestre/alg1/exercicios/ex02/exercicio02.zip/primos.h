#include <stdio.h>
#include <stdlib.h>

typedef int* indices_t;
typedef int* primos_t;

void encontrePrimos(primos_t primos, int maiorIndice);
int lendoNumeros(int quantidadePrimos, indices_t indices);

#include "lista.h"

void lendoPolinomio(lista_t *polinomio);
void adicionandoPolinomios(lista_t *polinomio1, lista_t *polinomio2);
void imprimir(lista_t *l);

#include <stdio.h>
#include <stdlib.h>

void uberSort(int* vetor, int inicio, int fim, int modo);
void pivot(int *vetor, int inicio, int fim, int modo);
void insertionSort(int *v, int ini, int fim);